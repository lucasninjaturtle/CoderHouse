
var num = prompt ("Ingrese un numero");

alert ("su numero ingresado es " + num);

